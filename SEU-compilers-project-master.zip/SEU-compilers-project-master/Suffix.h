#include<iostream>
#include<stack>
#include<queue>
#include<vector>
using namespace std;

string InfixToSuffix(string pattern);