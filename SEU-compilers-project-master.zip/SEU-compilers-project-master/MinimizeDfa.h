#pragma once
#include "DfaGraph.h"
#include <map>

class MinimizeDfa{
public:
	static DfaGraph Minimize(DfaGraph base);
};

